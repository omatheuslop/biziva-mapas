import en from './en_us'
import zh from './zh_cn'
import zhtw from './zh_tw'
import vi from './vi_vn'
import pt from './pt_br'

export default {
  pt,
  zh,
  zhtw,
  en,
  vi
}
