import * as portuguese from './pt'
import {
  fontSizeList,
  colorList,
  borderWidthList,
  borderRadiusList,
  lineWidthList,
  lineHeightList,
  store,
  langList,
  shapeListMap,
  lineStyleMap,
  fontFamilyList as fontFamilyListZh,
  borderDasharrayList as borderDasharrayListZh,
  lineStyleList as lineStyleListZh,
  rootLineKeepSameInCurveList as rootLineKeepSameInCurveListZh,
  backgroundRepeatList as backgroundRepeatListZh,
  backgroundPositionList as backgroundPositionListZh,
  shortcutKeyList as shortcutKeyListZh,
  shapeList as shapeListZh,
  sidebarTriggerList as sidebarTriggerListZh,
  backgroundSizeList as backgroundSizeListZh,
  downTypeList as downTypeListZh,
  numberTypeList as numberTypeListZh,
  numberLevelList as numberLevelListZh,
  linearGradientDirList as linearGradientDirListZh,
  alignList as alignListZh,
  layoutGroupList as layoutGroupListZh
} from './zh'
import {
  fontFamilyList as fontFamilyListEn,
  borderDasharrayList as borderDasharrayListEn,
  lineStyleList as lineStyleListEn,
  rootLineKeepSameInCurveList as rootLineKeepSameInCurveListEn,
  backgroundRepeatList as backgroundRepeatListEn,
  backgroundPositionList as backgroundPositionListEn,
  shortcutKeyList as shortcutKeyListEn,
  shapeList as shapeListEn,
  sidebarTriggerList as sidebarTriggerListEn,
  backgroundSizeList as backgroundSizeListEn,
  downTypeList as downTypeListEn,
  numberTypeList as numberTypeListEn,
  numberLevelList as numberLevelListEn,
  linearGradientDirList as linearGradientDirListEn,
  alignList as alignListEn,
  layoutGroupList as layoutGroupListEn
} from './en'
import {
  fontFamilyList as fontFamilyListZhtw,
  borderDasharrayList as borderDasharrayListZhtw,
  lineStyleList as lineStyleListZhtw,
  rootLineKeepSameInCurveList as rootLineKeepSameInCurveListZhtw,
  backgroundRepeatList as backgroundRepeatListZhtw,
  backgroundPositionList as backgroundPositionListZhtw,
  shortcutKeyList as shortcutKeyListZhtw,
  shapeList as shapeListZhtw,
  sidebarTriggerList as sidebarTriggerListZhtw,
  backgroundSizeList as backgroundSizeListZhtw,
  downTypeList as downTypeListZhtw,
  numberTypeList as numberTypeListZhtw,
  numberLevelList as numberLevelListZhtw,
  linearGradientDirList as linearGradientDirListZhtw,
  alignList as alignListZhtw,
  layoutGroupList as layoutGroupListZhtw
} from './zhtw'
import {
  fontFamilyList as fontFamilyListVi,
  borderDasharrayList as borderDasharrayListVi,
  lineStyleList as lineStyleListVi,
  rootLineKeepSameInCurveList as rootLineKeepSameInCurveListVi,
  backgroundRepeatList as backgroundRepeatListVi,
  backgroundPositionList as backgroundPositionListVi,
  shortcutKeyList as shortcutKeyListVi,
  shapeList as shapeListVi,
  sidebarTriggerList as sidebarTriggerListVi,
  backgroundSizeList as backgroundSizeListVi,
  downTypeList as downTypeListVi,
  numberTypeList as numberTypeListVi,
  numberLevelList as numberLevelListVi,
  linearGradientDirList as linearGradientDirListVi,
  alignList as alignListVi,
  layoutGroupList as layoutGroupListVi
} from './vi'

const fontFamilyList = {
  pt: portuguese.fontFamilyList,
  zh: fontFamilyListZh,
  en: fontFamilyListEn,
  zhtw: fontFamilyListZhtw,
  vi: fontFamilyListVi
}

const borderDasharrayList = {
  pt: portuguese.borderDasharrayList,
  zh: borderDasharrayListZh,
  en: borderDasharrayListEn,
  zhtw: borderDasharrayListZhtw,
  vi: borderDasharrayListVi
}

const lineStyleList = {
  pt: portuguese.lineStyleList,
  zh: lineStyleListZh,
  en: lineStyleListEn,
  zhtw: lineStyleListZhtw,
  vi: lineStyleListVi
}

const rootLineKeepSameInCurveList = {
  pt: portuguese.rootLineKeepSameInCurveList,
  zh: rootLineKeepSameInCurveListZh,
  en: rootLineKeepSameInCurveListEn,
  zhtw: rootLineKeepSameInCurveListZhtw,
  vi: rootLineKeepSameInCurveListVi
}

const backgroundRepeatList = {
  pt: portuguese.backgroundRepeatList,
  zh: backgroundRepeatListZh,
  en: backgroundRepeatListEn,
  zhtw: backgroundRepeatListZhtw,
  vi: backgroundRepeatListVi
}

const backgroundPositionList = {
  pt: portuguese.backgroundPositionList,
  zh: backgroundPositionListZh,
  en: backgroundPositionListEn,
  zhtw: backgroundPositionListZhtw,
  vi: backgroundPositionListVi
}

const backgroundSizeList = {
  pt: portuguese.backgroundSizeList,
  zh: backgroundSizeListZh,
  en: backgroundSizeListEn,
  zhtw: backgroundSizeListZhtw,
  vi: backgroundSizeListVi
}

const shortcutKeyList = {
  pt: portuguese.shortcutKeyList,
  zh: shortcutKeyListZh,
  en: shortcutKeyListEn,
  zhtw: shortcutKeyListZhtw,
  vi: shortcutKeyListVi
}

const shapeList = {
  pt: portuguese.shapeList,
  zh: shapeListZh,
  en: shapeListEn,
  zhtw: shapeListZhtw,
  vi: shapeListVi
}

const sidebarTriggerList = {
  pt: portuguese.sidebarTriggerList,
  zh: sidebarTriggerListZh,
  en: sidebarTriggerListEn,
  zhtw: sidebarTriggerListZhtw,
  vi: sidebarTriggerListVi
}

const downTypeList = {
  pt: portuguese.downTypeList,
  zh: downTypeListZh,
  en: downTypeListEn,
  zhtw: downTypeListZhtw,
  vi: downTypeListVi
}

const numberTypeList = {
  pt: portuguese.numberTypeList,
  zh: numberTypeListZh,
  en: numberTypeListEn,
  zhtw: numberTypeListZhtw,
  vi: numberTypeListVi
}

const numberLevelList = {
  pt: portuguese.numberLevelList,
  zh: numberLevelListZh,
  en: numberLevelListEn,
  zhtw: numberLevelListZhtw,
  vi: numberLevelListVi
}

const linearGradientDirList = {
  pt: portuguese.linearGradientDirList,
  zh: linearGradientDirListZh,
  en: linearGradientDirListEn,
  zhtw: linearGradientDirListZhtw,
  vi: linearGradientDirListVi
}

const alignList = {
  pt: portuguese.alignList,
  zh: alignListZh,
  en: alignListEn,
  zhtw: alignListZhtw,
  vi: alignListVi
}

const layoutGroupList = {
  pt: portuguese.layoutGroupList,
  zh: layoutGroupListZh,
  en: layoutGroupListEn,
  zhtw: layoutGroupListZhtw,
  vi: layoutGroupListVi
}

export {
  fontSizeList,
  borderWidthList,
  borderRadiusList,
  lineWidthList,
  lineHeightList,
  store,
  colorList,
  langList,
  fontFamilyList,
  borderDasharrayList,
  lineStyleList,
  lineStyleMap,
  rootLineKeepSameInCurveList,
  backgroundRepeatList,
  backgroundPositionList,
  backgroundSizeList,
  shortcutKeyList,
  shapeList,
  shapeListMap,
  sidebarTriggerList,
  downTypeList,
  numberTypeList,
  numberLevelList,
  linearGradientDirList,
  alignList,
  layoutGroupList
}
