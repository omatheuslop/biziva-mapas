// Biziva labels only; internal values, shortcuts and font families preserved.
export const alignList = [
  {
    "name": "Alinhar à esquerda",
    "value": "left"
  },
  {
    "name": "Centralizar",
    "value": "center"
  },
  {
    "name": "Alinhar à direita",
    "value": "right"
  }
]
export const backgroundPositionList = [
  {
    "name": "Padrão",
    "value": "0% 0%"
  },
  {
    "name": "Superior esquerdo",
    "value": "left top"
  },
  {
    "name": "Centro esquerdo",
    "value": "left center"
  },
  {
    "name": "Inferior esquerdo",
    "value": "left bottom"
  },
  {
    "name": "Superior direito",
    "value": "right top"
  },
  {
    "name": "Centro direito",
    "value": "right center"
  },
  {
    "name": "Inferior direito",
    "value": "right bottom"
  },
  {
    "name": "Superior central",
    "value": "center top"
  },
  {
    "name": "Centro",
    "value": "center center"
  },
  {
    "name": "Inferior central",
    "value": "center bottom"
  }
]
export const backgroundRepeatList = [
  {
    "name": "Não repetir",
    "value": "no-repeat"
  },
  {
    "name": "Repetir",
    "value": "repeat"
  },
  {
    "name": "Repetir-x",
    "value": "repeat-x"
  },
  {
    "name": "Repetir-y",
    "value": "repeat-y"
  }
]
export const backgroundSizeList = [
  {
    "name": "Automático",
    "value": "auto"
  },
  {
    "name": "Cobrir",
    "value": "cover"
  },
  {
    "name": "Conter",
    "value": "contain"
  }
]
export const borderDasharrayList = [
  {
    "name": "Sólido",
    "value": "none"
  },
  {
    "name": "Pontilhado1",
    "value": "5,5"
  },
  {
    "name": "Pontilhado2",
    "value": "10,10"
  },
  {
    "name": "Pontilhado3",
    "value": "20,10,5,5,5,10"
  },
  {
    "name": "Pontilhado4",
    "value": "5,5,1,5"
  },
  {
    "name": "Pontilhado5",
    "value": "15,10,5,10,15"
  },
  {
    "name": "Pontilhado6",
    "value": "1,5"
  },
  {
    "name": "Pontilhado7",
    "value": "6,4"
  }
]
export const downTypeList = [
  {
    "name": "Arquivo do mapa",
    "type": "smm",
    "icon": "iconwenjian",
    "desc": "Formato nativo editável do SimpleMindMap. Use para reabrir o mapa com suas configurações."
  },
  {
    "name": "Imagem",
    "type": "png",
    "icon": "iconPNG",
    "desc": "Imagem para visualizar e compartilhar"
  },
  {
    "name": "SVG",
    "type": "svg",
    "icon": "iconSVG",
    "desc": "Imagem vetorial escalável"
  },
  {
    "name": "PDF",
    "type": "pdf",
    "icon": "iconpdf",
    "desc": "Documento para visualizar e imprimir"
  },
  {
    "name": "Markdown",
    "type": "md",
    "icon": "iconmarkdown",
    "desc": "Texto Markdown compatível com outros editores"
  },
  {
    "name": "XMind",
    "type": "xmind",
    "icon": "iconxmind",
    "desc": "Arquivo do XMind"
  },
  {
    "name": "Txt",
    "type": "txt",
    "icon": "iconTXT",
    "desc": "Arquivo de texto simples"
  },
  {
    "name": "Excel",
    "type": "xlsx",
    "icon": "iconfile-excel",
    "desc": "Tabela editável no Excel"
  },
  {
    "name": "FreeMind",
    "type": "mm",
    "icon": "iconfreemind",
    "desc": "Formato do FreeMind"
  },
  {
    "name": "JSON",
    "type": "json",
    "icon": "iconjson",
    "desc": "Popular data exchange format that can be used for re importing"
  }
]
export const fontFamilyList = [
  {
    "name": "Song Ti",
    "value": "宋体, SimSun, Songti SC"
  },
  {
    "name": "Microsoft Yahei",
    "value": "微软雅黑, Microsoft YaHei"
  },
  {
    "name": "Itálico",
    "value": "楷体, 楷体_GB2312, SimKai, STKaiti"
  },
  {
    "name": "Negrito",
    "value": "黑体, SimHei, Heiti SC"
  },
  {
    "name": "Official script",
    "value": "隶书, SimLi"
  },
  {
    "name": "Andale Mono",
    "value": "andale mono"
  },
  {
    "name": "Arial",
    "value": "arial, helvetica, sans-serif"
  },
  {
    "name": "arialBlack",
    "value": "arial black, avant garde"
  },
  {
    "name": "Comic Sans Ms",
    "value": "comic sans ms"
  },
  {
    "name": "Impact",
    "value": "impact, chicago"
  },
  {
    "name": "Times New Roman",
    "value": "times new roman"
  },
  {
    "name": "Sem Serifa",
    "value": "sans-serif"
  },
  {
    "name": "serif",
    "value": "serif"
  }
]
export const layoutGroupList = [
  {
    "name": "Estrutura lógica",
    "list": [
      "logicalStructure",
      "logicalStructureLeft"
    ]
  },
  {
    "name": "Mapa mental",
    "list": [
      "mindMap"
    ]
  },
  {
    "name": "Estrutura de organização",
    "list": [
      "organizationStructure"
    ]
  },
  {
    "name": "Organização do catálogo",
    "list": [
      "catalogOrganization"
    ]
  },
  {
    "name": "Linha do tempo",
    "list": [
      "timeline",
      "timeline2",
      "verticalTimeline"
    ]
  },
  {
    "name": "Espinha de peixe",
    "list": [
      "fishbone"
    ]
  }
]
export const lineStyleList = [
  {
    "name": "Reta",
    "value": "straight"
  },
  {
    "name": "Curva",
    "value": "curve"
  },
  {
    "name": "Direto",
    "value": "direct"
  }
]
export const linearGradientDirList = [
  {
    "name": "Da esquerda para a direita",
    "value": "1",
    "start": [
      0,
      0
    ],
    "end": [
      1,
      0
    ]
  },
  {
    "name": "Da direita para a esquerda",
    "value": "2",
    "start": [
      1,
      0
    ],
    "end": [
      0,
      0
    ]
  },
  {
    "name": "De cima para baixo",
    "value": "3",
    "start": [
      0,
      0
    ],
    "end": [
      0,
      1
    ]
  },
  {
    "name": "De baixo para cima",
    "value": "4",
    "start": [
      0,
      1
    ],
    "end": [
      0,
      0
    ]
  },
  {
    "name": "Do canto superior esquerdo para o canto inferior direito",
    "value": "5",
    "start": [
      0,
      0
    ],
    "end": [
      1,
      1
    ]
  },
  {
    "name": "Do canto inferior esquerdo para o canto superior direito",
    "value": "6",
    "start": [
      0,
      1
    ],
    "end": [
      1,
      0
    ]
  },
  {
    "name": "Do canto superior direito para o canto inferior esquerdo",
    "value": "7",
    "start": [
      1,
      0
    ],
    "end": [
      0,
      1
    ]
  },
  {
    "name": "Do canto inferior direito para o canto superior esquerdo",
    "value": "8",
    "start": [
      1,
      1
    ],
    "end": [
      0,
      0
    ]
  }
]
export const numberLevelList = [
  {
    "name": "1 nível",
    "value": 1
  },
  {
    "name": "2 níveis",
    "value": 2
  },
  {
    "name": "3 níveis",
    "value": 3
  },
  {
    "name": "Todos os níveis",
    "value": 0
  }
]
export const numberTypeList = [
  {
    "name": "Nenhum",
    "value": ""
  },
  {
    "name": "1, 2, 3",
    "value": 1
  },
  {
    "name": "1., 2., 3.",
    "value": 2
  },
  {
    "name": "(1), (2), (3)",
    "value": 3
  },
  {
    "name": "a., b., c.",
    "value": 4
  },
  {
    "name": "A., B., C.",
    "value": 5
  },
  {
    "name": "i., ii., iii.",
    "value": 6
  },
  {
    "name": "I., II., III.",
    "value": 7
  },
  {
    "name": "一、, 二、, 三、",
    "value": 8
  }
]
export const rootLineKeepSameInCurveList = [
  {
    "name": "Chave",
    "value": false
  },
  {
    "name": "Chave",
    "value": true
  }
]
export const shapeList = [
  {
    "name": "Retângulo",
    "value": "rectangle"
  },
  {
    "name": "Losango",
    "value": "diamond"
  },
  {
    "name": "Paralelogramo",
    "value": "parallelogram"
  },
  {
    "name": "Retângulo arredondado",
    "value": "roundedRectangle"
  },
  {
    "name": "Retângulo octogonal",
    "value": "octagonalRectangle"
  },
  {
    "name": "Retângulo triangular externo",
    "value": "outerTriangularRectangle"
  },
  {
    "name": "Retângulo triangular interno",
    "value": "innerTriangularRectangle"
  },
  {
    "name": "Elipse",
    "value": "ellipse"
  },
  {
    "name": "Círculo",
    "value": "circle"
  }
]
export const shortcutKeyList = [
  {
    "type": "Operações com nós",
    "list": [
      {
        "icon": "icontianjiazijiedian",
        "name": "Inserir nó filho",
        "value": "Tab | Insert"
      },
      {
        "icon": "iconjiedian",
        "name": "Inserir nó irmão",
        "value": "Return"
      },
      {
        "icon": "icondodeparent",
        "name": "Inserir nó pai",
        "value": "Shift + Tab"
      },
      {
        "icon": "iconshangyi",
        "name": "Mover nó para cima",
        "value": "⌘ + ↑"
      },
      {
        "icon": "iconxiayi",
        "name": "Mover nó para baixo",
        "value": "⌘ + ↓"
      },
      {
        "icon": "icongaikuozonglan",
        "name": "Inserir resumo",
        "value": "⌘ + G"
      },
      {
        "icon": "iconzhankai",
        "name": "Expandir/Recolher nó",
        "value": "/"
      },
      {
        "icon": "iconshanchu",
        "name": "Excluir nó",
        "value": "Delete | Backspace"
      },
      {
        "icon": "iconshanchu",
        "name": "Excluir nó atual",
        "value": "Shift + Backspace"
      },
      {
        "icon": "iconfuzhi",
        "name": "Copiar nó",
        "value": "⌘ + C"
      },
      {
        "icon": "iconjianqie",
        "name": "Recortar nó",
        "value": "⌘ + X"
      },
      {
        "icon": "iconniantie",
        "name": "Colar nó",
        "value": "⌘ + V"
      },
      {
        "icon": "iconbianji",
        "name": "Editar nó",
        "value": "fn + F2"
      },
      {
        "icon": "iconhuanhang",
        "name": "Quebra de texto",
        "value": "Shift + Return"
      },
      {
        "icon": "iconhoutui-shi",
        "name": "Desfazer",
        "value": "⌘ + Z"
      },
      {
        "icon": "iconqianjin1",
        "name": "Refazer",
        "value": "⌘ + Y"
      },
      {
        "icon": "iconquanxuan",
        "name": "Selecionar tudo",
        "value": "⌘ + A"
      },
      {
        "icon": "iconquanxuan",
        "name": "Escolha múltipla",
        "value": "Clique direito / ⌘ + Clique esquerdo"
      },
      {
        "icon": "iconzhengli",
        "name": "Organizar layout",
        "value": "⌘ + L"
      },
      {
        "icon": "iconsousuo",
        "name": "Localizar e substituir",
        "value": "⌘ + F"
      }
    ]
  },
  {
    "type": "Operações da tela",
    "list": [
      {
        "icon": "iconfangda",
        "name": "Ampliar",
        "value": "⌘ + +"
      },
      {
        "icon": "iconsuoxiao",
        "name": "Reduzir",
        "value": "⌘ + -"
      },
      {
        "icon": "iconfangda",
        "name": "Ampliar/Reduzir",
        "value": "⌘ + Roda do mouse"
      },
      {
        "icon": "icondingwei",
        "name": "Voltar ao nó raiz",
        "value": "⌘ + Return"
      },
      {
        "icon": "iconquanping1",
        "name": "ajustar à tela",
        "value": "⌘ + i"
      }
    ]
  },
  {
    "type": "Operações da estrutura",
    "list": [
      {
        "icon": "iconhuanhang",
        "name": "Quebra de texto",
        "value": "Shift + Return"
      },
      {
        "icon": "iconshanchu",
        "name": "Excluir nó atual",
        "value": "Delete"
      },
      {
        "icon": "icontianjiazijiedian",
        "name": "Inserir nó filho",
        "value": "Tab"
      },
      {
        "icon": "iconjiedian",
        "name": "Inserir nó irmão",
        "value": "Return"
      },
      {
        "icon": "icondodeparent",
        "name": "Mover um nível acima",
        "value": "Shift + Tab"
      }
    ]
  }
]
export const sidebarTriggerList = [
  {
    "name": "Estilo do nó",
    "value": "nodeStyle",
    "icon": "iconzhuti"
  },
  {
    "name": "Estilo básico",
    "value": "baseStyle",
    "icon": "iconyangshi"
  },
  {
    "name": "Tema",
    "value": "theme",
    "icon": "iconjingzi"
  },
  {
    "name": "Estrutura",
    "value": "structure",
    "icon": "iconjiegou"
  },
  {
    "name": "Estrutura",
    "value": "outline",
    "icon": "iconfuhao-dagangshu"
  },
  {
    "name": "Configuração",
    "value": "setting",
    "icon": "iconshezhi"
  }
]
