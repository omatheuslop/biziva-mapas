import Vue from 'vue'
import VueI18n from 'vue-i18n'
import messages from './lang'
import ptUI from 'element-ui/lib/locale/lang/pt-br'
import enUI from 'element-ui/lib/locale/lang/en'
import zhUI from 'element-ui/lib/locale/lang/zh-CN'
import twUI from 'element-ui/lib/locale/lang/zh-TW'
import viUI from 'element-ui/lib/locale/lang/vi'
for (const [lang, ui] of Object.entries({pt:ptUI,en:enUI,zh:zhUI,zhtw:twUI,vi:viUI})) messages[lang].el = ui.el

Vue.use(VueI18n)

const i18n = new VueI18n({
  messages,
  fallbackLocale: 'en'
})

export default i18n
