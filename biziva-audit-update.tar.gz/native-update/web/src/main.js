import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import '@/assets/icon-font/iconfont.css'
import 'viewerjs/dist/viewer.css'
import VueViewer from 'v-viewer'
import i18n from './i18n'
import { getLang } from '@/api'
// import VConsole from 'vconsole'
// const vConsole = new VConsole()

Vue.config.productionTip = false
const bus = new Vue()
Vue.prototype.$bus = bus
Vue.use(ElementUI, { i18n: (key, value) => i18n.t(key, value) })
Vue.use(VueViewer)

const initApp = () => {
  // Biziva runs the complete web editor; do not show the upstream desktop trial promotion.
  try {
    if (localStorage.getItem('webUseTip') === null) localStorage.setItem('webUseTip', '1')
  } catch (_) { /* Private browsing can deny storage; editor startup still continues. */ }
  i18n.locale = getLang()
  new Vue({
    render: h => h(App),
    router,
    store,
    i18n
  }).$mount('#app')
}

// 是否处于接管应用模式
if (window.takeOverApp) {
  window.initApp = initApp
  window.$bus = bus
} else {
  initApp()
}
